const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const cors = require('cors');  // 1. Importa el módulo CORS

const app = express();

// 2. Configuración de CORS para permitir solo solicitudes desde tu frontend
const corsOptions = {
    origin: 'http://127.0.0.1:5500',  // Reemplaza con el puerto que estás usando en tu frontend
    optionsSuccessStatus: 200
};

app.use(cors(corsOptions));  // 3. Aplica CORS con las opciones configuradas

app.use(bodyParser.json());
app.use(express.static('public'));

// Conexión a la base de datos
mongoose.connect('mongodb://localhost:27017/Kevin_Panchana', {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => console.log('Conectado a MongoDB'))
.catch((err) => console.error('Error al conectar a MongoDB:', err));

// Importar y usar las rutas
const usuario = require('./src/components/usuario/interface');
app.use('/usuarios', usuario);

// Iniciar el servidor
app.listen(3001, () => {
    console.log('El servidor está corriendo en http://localhost:3001');
});
