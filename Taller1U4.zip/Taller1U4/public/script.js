const API_URL = 'http://localhost:3001/usuarios'; 

async function insertarUsuario() {
    const data = {
        usuario: document.getElementById('usuario').value,
        clave: document.getElementById('clave').value,
        nombre: document.getElementById('nombre').value,
        apellido: document.getElementById('apellido').value,
        fecha_nacimiento: document.getElementById('fecha_nacimiento').value
    };

    try {
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });

        const result = await response.json();
        document.getElementById('result').innerText = ''; // No mostrar mensaje después de la inserción
    } catch (error) {
        console.error('Error:', error);
    }
}

async function buscarUsuario() {
    const usuario = document.getElementById('usuario').value;

    try {
        const response = await fetch(`${API_URL}?usuario=${usuario}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            }
        });

        const result = await response.json();
        document.getElementById('result').innerText = JSON.stringify(result);
    } catch (error) {
        console.error('Error:', error);
    }
}

async function actualizarUsuario() {
    const data = {
        usuario: document.getElementById('usuario').value,
        clave: document.getElementById('clave').value,
        nombre: document.getElementById('nombre').value,
        apellido: document.getElementById('apellido').value,
        fecha_nacimiento: document.getElementById('fecha_nacimiento').value
    };

    try {
        const response = await fetch(API_URL, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });

        const result = await response.json();
        document.getElementById('result').innerText = ''; // No mostrar mensaje después de la actualización
    } catch (error) {
        console.error('Error:', error);
    }
}

async function eliminarUsuario() {
    const usuario = document.getElementById('usuario').value;

    try {
        const response = await fetch(API_URL, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ usuario })
        });

        const result = await response.json();
        document.getElementById('result').innerText = ''; 
    } catch (error) {
        console.error('Error:', error);
    }
}
